package shs.mobile01.Mealmate_version1a230524.View.Fragment;

import androidx.fragment.app.Fragment;

public class UserFragment extends Fragment {
}
