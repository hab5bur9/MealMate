package shs.mobile01.mealmate_version11.View.Fragment;

import androidx.fragment.app.Fragment;

public class UserFragment extends Fragment {
}
