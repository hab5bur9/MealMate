package shs.mobile01.Mealmate_version1a230524.viewModel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;


import shs.mobile01.Mealmate_version1a230524.Model.entity.User;
import shs.mobile01.Mealmate_version1a230524.Model.repository.UserRepository;

public class UserViewModel extends AndroidViewModel {
    private final UserRepository repository;

    public UserViewModel (Application application) {
        super(application);
        repository = UserRepository.getInstance(application);

    }

    public void insert(User user) { repository.insertUser(user); }

    public void update(User user) { repository.updateUser(user); }

    public void delete(User user) { repository.deleteUser(user); }
}
